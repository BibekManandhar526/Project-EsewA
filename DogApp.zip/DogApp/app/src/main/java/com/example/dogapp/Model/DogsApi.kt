package com.example.dogapp.Model


data class DogsAPi(val message:String)